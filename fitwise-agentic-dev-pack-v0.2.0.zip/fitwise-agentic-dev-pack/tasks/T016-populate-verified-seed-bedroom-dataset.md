# T016 — Populate verified seed bedroom dataset

**Phase:** Content engine  
**Dependencies:** T005  

## Objective

Complete this task without expanding scope into later tasks.

## Steps

- Add verified bed-size data for explicitly named markets and room/clearance assumptions.
- Include provenance.
- Populate bedroom page intents from INITIAL_CONTENT_MAP.csv.

## Acceptance criteria

- [ ] Validator passes.
- [ ] Market differences are explicit.
- [ ] No bed size is presented as globally universal.

## Required close-out

- [ ] Run relevant automated checks.
- [ ] Update `WORKLOG.md`.
- [ ] Update `WORKLOG.json`.
- [ ] Update `PROJECT_STATE.json`.
- [ ] Record any architecture change in `DECISIONS.md`.
