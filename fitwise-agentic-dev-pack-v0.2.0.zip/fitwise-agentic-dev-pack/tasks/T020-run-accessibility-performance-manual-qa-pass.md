# T020 — Run accessibility/performance/manual QA pass

**Phase:** QA  
**Dependencies:** T019  

## Objective

Complete this task without expanding scope into later tasks.

## Steps

- Run accessibility checks and manual keyboard test.
- Review representative pages at mobile/desktop widths.
- Run production-preview performance audit where tooling permits.
- Fix critical/serious accessibility issues and obvious performance regressions.

## Acceptance criteria

- [ ] QA findings documented.
- [ ] Critical/serious accessibility issues resolved.
- [ ] Performance/accessibility targets met or deviations explicitly documented.

## Required close-out

- [ ] Run relevant automated checks.
- [ ] Update `WORKLOG.md`.
- [ ] Update `WORKLOG.json`.
- [ ] Update `PROJECT_STATE.json`.
- [ ] Record any architecture change in `DECISIONS.md`.
