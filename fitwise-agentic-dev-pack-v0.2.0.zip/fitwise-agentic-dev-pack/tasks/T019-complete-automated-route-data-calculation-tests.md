# T019 — Complete automated route/data/calculation tests

**Phase:** QA  
**Dependencies:** T012, T013, T018  

## Objective

Complete this task without expanding scope into later tasks.

## Steps

- Implement the comprehensive static SEO gate suite from `specs/SEO_AUTOMATED_GATES.md` as part of `npm run verify` (mandatory despite the existing shorter task name).

- Expand test coverage to all calculation boundaries and representative generated pages.
- Add regression fixtures for discovered defects.
- Add smoke tests for homepage, hubs, dedicated pages, 404, sitemap and robots.

## Acceptance criteria

- [ ] Full automated suite passes from clean install.
- [ ] Failures exit non-zero.

## Required close-out

- [ ] Run relevant automated checks.
- [ ] Update `WORKLOG.md`.
- [ ] Update `WORKLOG.json`.
- [ ] Update `PROJECT_STATE.json`.
- [ ] Record any architecture change in `DECISIONS.md`.
