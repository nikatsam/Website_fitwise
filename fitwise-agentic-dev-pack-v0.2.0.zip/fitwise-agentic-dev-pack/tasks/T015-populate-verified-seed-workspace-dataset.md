# T015 — Populate verified seed workspace dataset

**Phase:** Content engine  
**Dependencies:** T005  

## Objective

Complete this task without expanding scope into later tasks.

## Steps

- Add verified seed data for common monitor screen sizes, selected overall-size examples if sourced, standard desk widths, gaps/margins and clearance assumptions.
- Include provenance and derivation IDs.
- Populate workspace page intents from INITIAL_CONTENT_MAP.csv.

## Acceptance criteria

- [ ] Validator passes.
- [ ] Every critical measurement has source or derivation provenance.
- [ ] No thin permutation explosion.

## Required close-out

- [ ] Run relevant automated checks.
- [ ] Update `WORKLOG.md`.
- [ ] Update `WORKLOG.json`.
- [ ] Update `PROJECT_STATE.json`.
- [ ] Record any architecture change in `DECISIONS.md`.
