# T017 — Implement metadata, canonicals, breadcrumbs and JSON-LD

**Phase:** SEO  
**Dependencies:** T014  

## Objective

Complete this task without expanding scope into later tasks.

## Steps

- Generate unique titles/descriptions and canonical URLs.
- Implement breadcrumb UI + BreadcrumbList JSON-LD.
- Add truthful WebPage metadata and social tags.
- Implement publication SEO envelope (with T004/T014 schema changes if needed) and stable publishedOn/significantlyModifiedOn data.
- Generate visible HTML breadcrumbs and matching BreadcrumbList JSON-LD from one typed hierarchy; render correctly escaped JSON-LD.
- Enforce canonical host `https://fitwise.stream`, normalized trailing slashes, hreflang only for real distinct locale pages; keep primary answer in static HTML.

## Acceptance criteria

- [ ] Representative pages contain required metadata.
- [ ] No duplicate launch-set titles/canonicals.
- [ ] Structured data parses as valid JSON.
- [ ] Each published indexable page has exact one self-canonical, real HTML answer/H1 and matching visible/JSON-LD breadcrumbs.
- [ ] T017 SEO metadata checks in `specs/SEO_AUTOMATED_GATES.md` pass, including negative fixtures.

## Required close-out

- [ ] Run relevant automated checks.
- [ ] Update `WORKLOG.md`.
- [ ] Update `WORKLOG.json`.
- [ ] Update `PROJECT_STATE.json`.
- [ ] Record any architecture change in `DECISIONS.md`.
