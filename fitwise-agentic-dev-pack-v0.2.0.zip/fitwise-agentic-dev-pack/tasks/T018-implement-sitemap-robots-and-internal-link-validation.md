# T018 — Implement sitemap, robots and internal-link validation

**Phase:** SEO  
**Dependencies:** T014, T017  

## Objective

Complete this task without expanding scope into later tasks.

## Steps

- Generate sitemap from published page intents.
- Ensure draft/deferred pages are excluded.
- Add robots policy.
- Implement internal related-link validator.
- Implement production `robots.txt` with absolute sitemap reference; sitemap generated from published canonical PageIntent registry on every build.
- Apply stable truthful sitemap lastmod (no build-time timestamp), exclude draft/deferred/deprecated/noindex/redirect URLs; verify XML sizing & escaping.
- Add optional local-only URL deploy diff manifest (`added/materiallyUpdated/removed/unchanged`) and documented redirect registry for renamed/merged routes.
- Implement offline `npm run validate:seo` and `npm run seo:diff` (no network calls) per `specs/SEO_AUTOMATED_GATES.md`.

## Acceptance criteria

- [ ] Published routes appear once in sitemap.
- [ ] Draft routes absent.
- [ ] No broken generated related links.
- [ ] No-op rebuild leaves sitemap lastmod unchanged.
- [ ] Published canonical/sitemap/robots/head/meta rules align.
- [ ] Invalid fixtures fail `validate:seo`, including noindex in sitemap, duplicate canonical, broken crumb, missing link and draft route.

## Required close-out

- [ ] Run relevant automated checks.
- [ ] Update `WORKLOG.md`.
- [ ] Update `WORKLOG.json`.
- [ ] Update `PROJECT_STATE.json`.
- [ ] Record any architecture change in `DECISIONS.md`.
